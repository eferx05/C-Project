﻿using System;
using System.Linq;

namespace Kullanıcıdan_alınan_2_sayı_ile_matematiksel_işlamler;

public static class Program
{
    public static void Main()
    {
        Console.WriteLine("1. sayiyi girin");
        int sayi1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("2. sayiyi girin");
        int sayi2 = Convert.ToInt32(Console.ReadLine());

        int toplam = sayi1 + sayi2;
        int fark = sayi1 - sayi2;
        int carp = sayi1 * sayi2;
        int bol = sayi1 / sayi2;
        int mod = sayi1 % sayi2;

        Console.WriteLine("Iki sayinin toplami {0}  ", toplam);
        Console.WriteLine("Iki sayinin farki {0}  ", fark);
        Console.WriteLine("Iki sayinin carpimi {0}  ", carp);
        Console.WriteLine("Iki sayinin bolumu {0}  ", bol);
        Console.WriteLine("birinci sayinin ikinci sayiya gore mod u {0}  ", mod);

    }
}
